#### Data Description

---

* The dataset is a subset of the MNITS dataset [1], which contains 12700 training images and 2167 testing images. 
* Each image consists of 784 features.
* The label of each image is either 1 or 2.
* The data sets are stored in “*.mat” files and in a sparse way.  **You should convert it to full storage before implement your algorithm.**



[1] <http://yann.lecun.com/exdb/mnist/>

